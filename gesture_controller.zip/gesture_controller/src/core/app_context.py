from PySide6.QtCore import QObject, Signal

class AppContext(QObject):
    """Gestiona el estado global y señales compartidas de la aplicación."""
    
    gesture_detected = Signal(str)          # Nombre del gesto
    detection_state_changed = Signal(bool)  # Activar/desactivar detección
    calibration_triggered = Signal()        # Señal de calibración

    def __init__(self):
        super().__init__()
        self.is_detection_active = False
        self.last_gesture = None

    def set_detection_active(self, state: bool):
        """Cambia el estado de detección y emite la señal."""
        self.is_detection_active = state
        self.detection_state_changed.emit(state)

    def emit_gesture(self, gesture_name: str):
        """Emite el gesto detectado."""
        self.last_gesture = gesture_name
        self.gesture_detected.emit(gesture_name)

    def trigger_calibration(self):
        """Emite señal de calibración."""
        self.calibration_triggered.emit()


# Instancia global accesible en toda la app
app_context = AppContext()
