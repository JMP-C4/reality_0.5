"""
hand_tracking.py
----------------
Módulo encargado de la detección y rastreo de manos en tiempo real.
Usa MediaPipe Tasks (modelo `hand_landmarker.task`) para obtener los landmarks de la mano.

Responsabilidades:
- Inicializar el modelo de MediaPipe.
- Procesar frames provenientes de OpenCV.
- Retornar coordenadas de la(s) mano(s) detectada(s).
"""

import mediapipe as mp
import cv2
from mediapipe.tasks import python
from mediapipe.tasks.python import vision
from pathlib import Path


class HandTracker:
    def __init__(self, model_path: str = None):
        """
        Inicializa el detector de manos.
        """
        # Carga del modelo hand_landmarker.task
        if model_path is None:
            model_path = Path(__file__).resolve().parent.parent.parent / "assets" / "hand_landmarker.task"

        if not Path(model_path).exists():
            raise FileNotFoundError(f"No se encontró el modelo en: {model_path}")

        base_options = python.BaseOptions(model_asset_path=str(model_path))
        options = vision.HandLandmarkerOptions(
            base_options=base_options,
            num_hands=2,
            min_hand_detection_confidence=0.6,
            min_tracking_confidence=0.5
        )

        self.detector = vision.HandLandmarker.create_from_options(options)

    def process_frame(self, frame):
        """
        Procesa un frame (imagen de OpenCV) y detecta las manos.
        Devuelve un objeto con los resultados de MediaPipe.
        """
        mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
        result = self.detector.detect(mp_image)
        return result

    def close(self):
        """Libera recursos del detector."""
        del self.detector
