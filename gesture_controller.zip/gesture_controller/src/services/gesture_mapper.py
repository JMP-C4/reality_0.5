"""
gesture_mapper.py
Responsable de traducir los datos de MediaPipe (posición de la mano y dedos)
en gestos definidos (como clic, mover, deslizar, etc.).
"""

class GestureMapper:
    def __init__(self):
        """
        Inicializa el mapeador de gestos con configuraciones básicas.
        """
        self.last_gesture = None

    def detect_gesture(self, hand_landmarks):
        """
        Recibe los puntos de referencia de la mano y detecta gestos conocidos.

        :param hand_landmarks: lista de puntos (x, y, z) provenientes de MediaPipe
        :return: str con el nombre del gesto detectado
        """
        # Ejemplo básico: detectar si el pulgar y el índice están juntos (gesto de clic)
        if not hand_landmarks:
            return None

        thumb_tip = hand_landmarks[4]
        index_tip = hand_landmarks[8]

        distance = ((thumb_tip.x - index_tip.x) ** 2 + (thumb_tip.y - index_tip.y) ** 2) ** 0.5

        if distance < 0.05:
            gesture = "click"
        else:
            gesture = "move"

        self.last_gesture = gesture
        return gesture
