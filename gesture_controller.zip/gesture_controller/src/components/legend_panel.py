from PySide6.QtWidgets import QFrame, QLabel, QVBoxLayout
from PySide6.QtCore import Qt

class LegendPanel(QFrame):
    """Panel de leyenda de gestos."""
    def __init__(self):
        super().__init__()
        self.setFrameShape(QFrame.StyledPanel)
        layout = QVBoxLayout()

        legend_text = (
            "--- Leyenda de Gestos ---\n"
            "✋ Mano abierta → Cursor libre\n"
            "🤞 Pinch → Clic\n"
            "👉 Point → Seleccionar\n"
            "🖐️ Wave → Recalibrar cámara\n"
        )

        self.lbl_legend = QLabel(legend_text)
        self.lbl_legend.setAlignment(Qt.AlignLeft | Qt.AlignTop)
        layout.addWidget(self.lbl_legend)
        self.setLayout(layout)
