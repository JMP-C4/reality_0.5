from PySide6.QtWidgets import QWidget, QPushButton, QVBoxLayout
from src.core.app_context import app_context

class ControlPanel(QWidget):
    """Panel de control con botones de acción."""
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout()

        self.btn_toggle = QPushButton("Iniciar Detección")
        self.btn_toggle.clicked.connect(self.toggle_detection)
        layout.addWidget(self.btn_toggle)

        self.btn_calibrate = QPushButton("Calibrar")
        self.btn_calibrate.clicked.connect(app_context.trigger_calibration)
        layout.addWidget(self.btn_calibrate)

        self.btn_exit = QPushButton("Salir")
        layout.addWidget(self.btn_exit)

        self.setLayout(layout)

        # Escucha cambios de detección
        app_context.detection_state_changed.connect(self.update_button)

    def toggle_detection(self):
        new_state = not app_context.is_detection_active
        app_context.set_detection_active(new_state)

    def update_button(self, state: bool):
        self.btn_toggle.setText("Detener Detección" if state else "Iniciar Detección")
