import cv2
from PySide6.QtWidgets import QWidget, QLabel, QHBoxLayout, QVBoxLayout
from PySide6.QtGui import QImage, QPixmap
from PySide6.QtCore import QTimer, Qt
from src.services.hand_tracking import HandTracker
from src.services.gesture_mapper import GestureMapper
from src.controllers.gesture_controller import GestureController
from src.core.app_context import app_context
from .control_panel import ControlPanel
from .legend_panel import LegendPanel

class MainWindow(QWidget):
    """Ventana principal que integra cámara, detección y paneles."""
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Control por Gestos v0.4")
        self.resize(1200, 700)

        self.hand_tracker = HandTracker()
        self.gesture_mapper = GestureMapper()
        self.gesture_controller = GestureController()

        self.video_label = QLabel("Esperando cámara...")
        self.video_label.setAlignment(Qt.AlignCenter)
        self.video_label.setFixedSize(640, 480)

        self.control_panel = ControlPanel()
        self.legend_panel = LegendPanel()

        layout = QHBoxLayout(self)
        left = QVBoxLayout()
        left.addWidget(self.video_label)

        right = QVBoxLayout()
        right.addWidget(self.control_panel)
        right.addWidget(self.legend_panel)
        right.addStretch()

        layout.addLayout(left, 3)
        layout.addLayout(right, 1)
        self.setLayout(layout)

        # Configurar cámara
        self.cap = cv2.VideoCapture(0)
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_frame)
        self.timer.start(30)

        # Escuchar señales
        app_context.detection_state_changed.connect(self.toggle_camera)

    def toggle_camera(self, state):
        if state:
            self.timer.start(30)
        else:
            self.timer.stop()

    def update_frame(self):
        ret, frame = self.cap.read()
        if not ret:
            return
        frame = cv2.flip(frame, 1)
        result = self.hand_tracker.process_frame(frame)
        if result.hand_landmarks:
            gesture = self.gesture_mapper.detect_gesture(result.hand_landmarks[0])
            app_context.emit_gesture(gesture)
        self.display_frame(frame)

    def display_frame(self, frame):
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        h, w, ch = rgb.shape
        qimg = QImage(rgb.data, w, h, ch * w, QImage.Format_RGB888)
        pixmap = QPixmap.fromImage(qimg)
        self.video_label.setPixmap(pixmap.scaled(self.video_label.size(), Qt.KeepAspectRatio))

    def closeEvent(self, event):
        self.timer.stop()
        self.cap.release()
        cv2.destroyAllWindows()
        event.accept()
