from src.services.hand_tracking import HandTracker
from src.controllers.system_actions import SystemActions

class GestureController:
    def __init__(self):
        self.tracker = HandTracker()
        self.actions = SystemActions()

    def update(self, frame):
        """Llama a HandTracker para obtener coordenadas y mueve el cursor."""
        landmarks = self.tracker.process_frame(frame)

        if landmarks is not None:
            x, y = landmarks[0]  # Ejemplo: punto índice (dedo)
            screen_x = int(x * 1920)  # escala a resolución de pantalla
            screen_y = int(y * 1080)
            self.actions.move_mouse(screen_x, screen_y)
