"""
Controlador de acciones del sistema.
Permite mover el mouse, hacer clics o ejecutar comandos asociados a gestos.
"""

import pyautogui

class SystemActions:
    def __init__(self):
        # Configuración inicial de pyautogui
        pyautogui.FAILSAFE = False
        pyautogui.PAUSE = 0

    def move_mouse(self, x, y):
        """Mueve el mouse a la posición indicada (x, y)."""
        screen_width, screen_height = pyautogui.size()
        # Asegurar que no se salga de la pantalla
        x = max(0, min(screen_width, x))
        y = max(0, min(screen_height, y))
        pyautogui.moveTo(x, y, duration=0.01)

    def click(self):
        """Realiza un clic izquierdo."""
        pyautogui.click()

    def double_click(self):
        """Realiza doble clic."""
        pyautogui.doubleClick()

    def right_click(self):
        """Clic derecho."""
        pyautogui.rightClick()

    def scroll(self, amount):
        """Desplaza la rueda del mouse."""
        pyautogui.scroll(amount)
